/*package com.project.library.Library_Management.Student;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

//@Controller
public class StudentController {

	
	public StudentController(StudentService studentService) {
		super();
		this.studentService = studentService;
	}
	private StudentService studentService;
	@RequestMapping(value="/userslist")
	public String allStudents(ModelMap model) {
		List<Student> allstudents= studentService.AllStudents("Saroj");
		model.addAttribute("allstudents",allstudents);
		return "students";
	}
}
*/
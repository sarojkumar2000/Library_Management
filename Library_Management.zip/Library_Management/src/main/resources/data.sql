insert into book(book_id,author,no_of_available,publisher,title)
values(1,'XYZ','05','sun microsystems','Java');



insert into book(book_id,author,no_of_available,publisher,title)
values(2,'XYZ','03','sun microsystems','MYSQL');



insert into book(book_id,author,no_of_available,publisher,title)
values(3,'XYZ','04','sun microsystems','Spring Boot');

insert into students(id,name,branch,course)
values(1,'saroj','CSE','BTECH');


insert into students(id,name,branch,course)
values(2,'Mani','CSE','BTECH');

insert into students(id,name,branch,course)
values(3,'Anusha','CSE','BTECH');


insert into students(id,name,branch,course)
values(4,'Suma','CSE','BTECH');


